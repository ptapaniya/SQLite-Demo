//
//  Person.swift
//  SQLIte
//
//  Created by Prakash on 17/05/20.
//  Copyright © 2020 Prakash. All rights reserved.
//

import Foundation

class person {
    
    var name : String = ""
    var age : Int = 0
    var id : Int = 0
    
    init(id: Int, name: String, age: Int) {
        
        self.id = id
        self.name = name
        self.age = age
    }
}
