//
//  ViewController.swift
//  SQLIte
//
//  Created by Prakash on 17/05/20.
//  Copyright © 2020 Prakash. All rights reserved.
//

import UIKit

var isInsert = true

class ViewController: UIViewController, EditDelegateProtocol {
   
    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var txtAge: UITextField!
    @IBOutlet weak var btnAdd: UIButton!
    
    var personID : Int?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
       
    }
    
    override func viewWillAppear(_ animated: Bool) {
    
    }

    @IBAction func btnAdd_Action(_ sender: UIButton) {
        
        let personName = txtName.text ?? ""
        let personAge = Int(txtAge.text ?? "") ?? 0
        
        if !isInsert
        {
            db.update(id:personID!, name: personName, age: personAge)
            
        }else{
            db.insert(name: personName, age: personAge)
            isInsert = true
        }

        
        self.txtName.text = ""
        self.txtAge.text = ""
        
        let PersonTableView = self.storyboard?.instantiateViewController(withIdentifier: "PersonVC") as! PersonVC
        PersonTableView.delegate = self
        self.navigationController?.pushViewController(PersonTableView, animated: true)
    }
    
    @IBAction func btnShow_Action(_ sender: UIButton) {
        let PersonTableView = self.storyboard?.instantiateViewController(withIdentifier: "PersonVC") as! PersonVC
        PersonTableView.delegate = self
        self.navigationController?.pushViewController(PersonTableView, animated: true)
    }
    
    // Get data Using Delegate Protocol
    func EditData(_ id: Int, _ name: String, _ age: Int) {
        
        personID = id
        self.txtName.text = name
        self.txtAge.text = "\(age)"
    }
       
}

