//
//  PersonVC.swift
//  SQLIte
//
//  Created by Prakash on 17/05/20.
//  Copyright © 2020 Prakash. All rights reserved.
//

import UIKit

protocol EditDelegateProtocol : class {
    
    func EditData(_ id : Int, _ name: String, _ age : Int)
}

class PersonVC: UIViewController, UISearchBarDelegate {

    @IBOutlet weak var tblPerson: UITableView!
    @IBOutlet weak var searchBar: UISearchBar!
    
    var arrPerson = [person]()
    var arrFilter = [person]()
    
    var db : DBHelper = DBHelper()
    
    weak var delegate : EditDelegateProtocol?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.tblPerson.register(UINib(nibName: "PersonTableViewCell", bundle: nil), forCellReuseIdentifier: "PersonTableViewCell")
        
        arrPerson = db.read()
        
        arrFilter = arrPerson
        
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
        arrFilter = searchBar.text!.isEmpty ? arrPerson : arrPerson.filter({ item in
            
            return (item.name).range(of: searchText, options: .caseInsensitive, range: nil, locale: nil) != nil
        })
            
        tblPerson.reloadData()
    }
    
}

extension PersonVC : UITableViewDelegate, UITableViewDataSource
{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrFilter.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "PersonTableViewCell", for: indexPath) as! PersonTableViewCell
        
        cell.lblPersonDetails.text = "Name : \(arrFilter[indexPath.row].name) , Age : \(arrFilter[indexPath.row].age)"
        
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        isInsert = false
        delegate?.EditData(arrFilter[indexPath.row].id,arrFilter[indexPath.row].name, arrFilter[indexPath.row].age)
        self.navigationController?.popViewController(animated: true)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50.0
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        db.deleteByID(id: arrFilter[indexPath.row].id)
        arrFilter = db.read()
        self.tblPerson.reloadData()
    }
}
